## Images for use with promoting Skia4Delphi

#  

<img src="logo-gradient.svg" width=360 height=220>
<img src="logo-black.svg" width=360 height=220>
<img src="logo-white.svg" width=360 height=220>
